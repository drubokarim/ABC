<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class CountryModelOl extends Model {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "countries";
    protected $primaryKey = 'id';
    protected $guarded = 'id';
    protected $fillable = [
        'country_code',
        'country_name'
    ];

}
