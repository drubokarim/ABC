<!DOCTYPE html>
<html>
<head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title><?php echo $__env->yieldContent('title'); ?></title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
body {
    overflow:hidden;
}
</style>
</head>
<body>
   <div class="container">
	<section>
   <div class="dropdown" style="float: right;" >
    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style="float: right;background-color: white;color: black;border-color: white">Admin
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
      <li><a href="#">Profile</a></li>
      <li><a href="<?php echo e(route('logout.index')); ?>">Logout</a></li>
      
    </ul>
  </div>
   
   <h2 style="color: green;">

      <table>
         <tr>
            <th rowspan="2">
              <img src="<?php echo e(asset('/photos/logo.PNG')); ?>" alt="logo" style="width: 100%;"> 
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
              <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

            </th>
            <th>
              CHITTAGONG CANTONMENT PUBLIC COLLEGE  
            </th>
            
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <td>
               
   
               </td>
         </tr>
         <tr>
            <td>
               <span lang="bn" style="color: blue">চট্টগ্রাম ক্যান্টনমেন্ট পাবলিক কলেজ</span>
            </td>
         </tr>
      </table>

   </h2>
   	 </section>

      
   	
   	
   <nav class="navbar navbar-default" >
  <div class="container-fluid">
   

   <ul class="nav navbar-nav">
   <li><a href="<?php echo e(route('home.index')); ?>">HOME</a></li>
   <li><a href="<?php echo e(route('home.show')); ?>">All Applications</a></li>
   <li><a href="#">Send Reminder SMS</a></li>
   <li><a href="#">Transaction Log</a></li>
   <li><a href="<?php echo e(route('logout.index')); ?>">Logout</a></li>
   </ul>
   
</div>
</nav>

   <section style="float: center" class="panel panel-default">
   	 <?php echo $__env->yieldContent('component'); ?>

   </section>
</div>
  </body>

</html>