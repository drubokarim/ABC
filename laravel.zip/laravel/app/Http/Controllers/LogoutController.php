<?php

namespace App\Http\Controllers;
use Cache;
use Illuminate\Http\Request;

class LogoutController extends Controller
{
    public function index()
    {
    	session()->flush();
    	Cache::flush();
    	//Input::clear();
    	return redirect()->route('login.index');
    }
}
