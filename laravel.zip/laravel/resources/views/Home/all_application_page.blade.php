@extends('Layout.layout')

@section('title')
All Aplication Page
@endsection

@section('component')
<center>
	<table class="table">
		<tr>
			<td>
				Search
			</td>

		</tr>
        <form method="post">
        	{{csrf_field()}}
        	<tr>
			
			<td>
				<input type="text" name="byName" placeholder="By Name" style="color: gray">
			</td>
			<td>
				<input type="text" name="uniqueCode" placeholder="Unique Code" style="color: gray">
			</td>
			<td>
				<input type="text" name="searchByMobileNo" placeholder="Search By Mobile No" style="color: gray">
			</td>
			<td>
				<select name="paidStatus">
					<option>Paid/Unpaid</option>
					<option value="Paid">Paid</option>
					<option value="Unpaid">Unpaid</option>
				</select>
			</td>
			
		</tr>
		<tr>
			
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Search" style="background-color: skyblue; color: white" class="btn btn-primary btn-md">
			</td>
		
			<td>
				<input type="submit" name="submit" value="Export To Excel" style="background-color: green; color: white" class="btn btn-primary btn-md">
			</td>
			<td>
				<a href="{{route('home.show_verify',['id'=>session('user')->id])}}" class="btn btn-primary btn-sm" style="background-color:red;border-color: red">Verify Payment Staus</a>
			</td>
		</tr>
		
		</form>
	</table>
	<br>
	<table class="table" style="width: : 100%;height: 100%">
		<tr>
			<th colspan="7">
				All Applications:: Total {{$applicantsNo}} applicants found
			</th>
		</tr>
		<tr>
			<th>
				Name
			</th>
			<th>
				Registration Id
			</th>
			<th>
				Mobile No
			</th>
			<th>
				Has Paid
			</th>
			<th>
				Country
			</th>
			<th>
				Guest
			</th>
			<th>
				Actions
			</th>
		</tr>
		@foreach($applicants as $applicant)
		<tr>
			<td>
				{{$applicant->a_name}}
			</td>
			<td>
				{{$applicant->a_reg_no}}
			</td><td>
				{{$applicant->a_mobile}}
			</td>

			<td>
				@if($applicant->a_ssl_payment_status=='Paid' && $applicant->a_payment_status=='Paid')
					Paid
				@else
				    Unpaid
				@endif   	
			</td>
			<td>
				{{$applicant->country_name}}
			</td>
			<td>
				{{$applicant->a_guest}}
			</td>
			<td>
				<a href="{{route('home.show_specific',['id'=>$applicant->a_id])}}" class="btn btn-primary btn-sm">View</a>
				<!--<a href="{{route('home.show_verify',['id'=>$applicant->a_id])}}" class="btn btn-primary btn-sm" style="background-color:red;border-color: red">Verify</a>-->
			</td>
		</tr>
		@endforeach
		
		
		
					
	</table>
		{{ $applicants->links()}}
</center>
@endsection