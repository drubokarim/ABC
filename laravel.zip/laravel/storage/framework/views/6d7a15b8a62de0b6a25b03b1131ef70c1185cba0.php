<?php $__env->startSection('title'); ?>
Reporting Panel (Dashboard)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('component'); ?>
<center>
	<h1>
		Dashboard and Statistics
	</h1>
	<table class="table" style="padding: 10px">
			<tr>
				<td >
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #00b3b3"><?php echo e(session('reg')); ?></h2>
						<p style=" color:  #d1d1e0;"> 
						Total Registrations
					     </p>
					</div>
				</td>
				<td>
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #ff751a"><?php echo e(session('totalParticipant')); ?></h2> 
						<p style="color:  #d1d1e0;">
						Total Participant
						</p>
					</div>
				</td>
				<td>
       
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #d1d1e0"> <?php echo e(session('total')); ?></h2>
						<p style="color:  #d1d1e0;"> 
						Total Paid
						</p>
					</div>
				</td>
				<td>
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #d1d1e0"><?php echo e(session('guest')); ?></h2>
						<p style="color:  #d1d1e0;"> 
						Total Guest
						</p>
					</div>
				</td>
				<td>
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #d1d1e0"><?php echo e(session('ticket')); ?></h2>
						<p style="color:  #d1d1e0;"> 
						Total Ticket Delivered
						</p>
					</div>
				</td>
			</tr>
		</table>
		<img src="<?php echo e(asset('/photos/abc.PNG')); ?>" style="width: 100%">
	
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>