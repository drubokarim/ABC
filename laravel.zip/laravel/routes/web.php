<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/


Route::get('/','LoginController@index')->name('login.index');
Route::post('/','LoginController@verify')->name('login.verify');

Route::get('/logout','LogoutController@index')->name('logout.index');

Route::group(['middleware'=>['sess']],function(){
	Route::group(['middleware'=>['abc']],function(){
		Route::get('/home','AdminController@index')->name('home.index');

		Route::get('/home/show/all','AdminController@show')->name('home.show');
		Route::post('/home/show/all','AdminController@showSearch')->name('home.show.search');

		Route::get('/home/show/{id}','AdminController@show_specific')->name('home.show_specific');
		Route::post('/home/show/{id}','AdminController@show_specific_verify')->name('home.show_specific_verify');
		
		Route::get('/home/show/{id}/verify','AdminController@show_verify')->name('home.show_verify');
		Route::post('/home/show/{id}/verify','AdminController@show_verify_update')->name('home.show_verify_update');

		});
});
