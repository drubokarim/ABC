<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index()
    {
    	return view('Login.login');
    }
    public function verify(Request $request)
    {
    	$user= DB::table('users')
	    	->where('username',$request->username)
	    	->where('password',$request->password)
	    	->first();
	    if($user != null)
    	{
            //echo 'hello';
            //$request->session()->flash('message', 'please Login');
			$request->session()->put('user',$user);
			//if($user->type=='Admin')
    		return redirect()->route('home.index');
		                     
		    //else if($user->type=='User')
    		//return redirect()->route('user.home.index',$user->userId);
		                     
    	}
    	else
    	{
    		$request->session()->flash('username', $request->username);
    		$request->session()->flash('message', 'Invalid username or password');
    		/*return view('login.index')
    			->with('username', $un)
    			->with('message', 'Invalid username or password');*/
    		return redirect()->route('login.index');
    	}

    	
    }
}
