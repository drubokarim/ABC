<?php $__env->startSection('title'); ?>
All Aplication Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('component'); ?>
<center>
	<table class="table">
		<tr>
			<td>
				Search
			</td>

		</tr>
        <form method="post">
        	<?php echo e(csrf_field()); ?>

        	<tr>
			
			<td>
				<input type="text" name="byName" placeholder="By Name" style="color: gray">
			</td>
			<td>
				<input type="text" name="uniqueCode" placeholder="Unique Code" style="color: gray">
			</td>
			<td>
				<input type="text" name="searchByMobileNo" placeholder="Search By Mobile No" style="color: gray">
			</td>
			<td>
				<select name="paidStatus">
					<option>Paid/Unpaid</option>
					<option value="Paid">Paid</option>
					<option value="Unpaid">Unpaid</option>
				</select>
			</td>
			
		</tr>
		<tr>
			
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Search" style="background-color: skyblue; color: white" class="btn btn-primary btn-md">
			</td>
		
			<td>
				<input type="submit" name="submit" value="Export To Excel" style="background-color: green; color: white" class="btn btn-primary btn-md">
			</td>
			<td>
				<a href="<?php echo e(route('home.show_verify',['id'=>session('user')->id])); ?>" class="btn btn-primary btn-sm" style="background-color:red;border-color: red">Verify Payment Staus</a>
			</td>
		</tr>
		
		</form>
	</table>
	<br>
	<table class="table" style="width: : 100%;height: 100%">
		<tr>
			<th colspan="7">
				All Applications:: Total <?php echo e($applicantsNo); ?> applicants found
			</th>
		</tr>
		<tr>
			<th>
				Name
			</th>
			<th>
				Registration Id
			</th>
			<th>
				Mobile No
			</th>
			<th>
				Has Paid
			</th>
			<th>
				Country
			</th>
			<th>
				Guest
			</th>
			<th>
				Actions
			</th>
		</tr>
		<?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>
				<?php echo e($applicant->a_name); ?>

			</td>
			<td>
				<?php echo e($applicant->a_reg_no); ?>

			</td><td>
				<?php echo e($applicant->a_mobile); ?>

			</td>

			<td>
				<?php if($applicant->a_ssl_payment_status=='Paid' && $applicant->a_payment_status=='Paid'): ?>
					Paid
				<?php else: ?>
				    Unpaid
				<?php endif; ?>   	
			</td>
			<td>
				<?php echo e($applicant->country_name); ?>

			</td>
			<td>
				<?php echo e($applicant->a_guest); ?>

			</td>
			<td>
				<a href="<?php echo e(route('home.show_specific',['id'=>$applicant->a_id])); ?>" class="btn btn-primary btn-sm">View</a>
				<!--<a href="<?php echo e(route('home.show_verify',['id'=>$applicant->a_id])); ?>" class="btn btn-primary btn-sm" style="background-color:red;border-color: red">Verify</a>-->
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		
		
					
	</table>
		<?php echo e($applicants->links()); ?>

</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>