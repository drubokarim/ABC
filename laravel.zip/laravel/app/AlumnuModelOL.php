<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class AlumnuModelOL extends Model {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "alumnus";
    protected $primaryKey = 'a_id';
    protected $guarded = 'a_id';
    protected $fillable = [
        'a_name',
        'a_mobile',
        'a_email',
        'a_country',
        'a_passing_year',
        'a_present_address',
        'a_guest',
        'a_guest_no',
        'a_reg_no',
        'a_payment_amount',
        'a_payment_status'
    ];

}
