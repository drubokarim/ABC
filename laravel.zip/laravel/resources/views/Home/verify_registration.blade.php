@extends('Layout.layout')

@section('title')
Verification Page
@endsection

@section('component')

	<center>
	
		<label><h1>Registration Verification</h1>
		</label>
		<form method="post">
			{{csrf_field()}}
			<table>
				<tr>
					<td>
						<h2>Registration Id</h2>
					</td>
					<td>
						<input type="text" name="regNo" style="height: 50px;width: 200px" required><br>
					</td>
				</tr>
				<tr>
					<td>
						
					</td>
					<td>
						<input type="submit" name="" value="Verify Now" style="color: white; background-color:  #660066; height:50px;width: 100px;font-size: 100%" class="btn btn-primary btn-md">
					</td>
				</tr>
			</table>	
		</form>
		
	
	@if(session('messageStatus')!=null )
	<table class="table">
		<tr>
			<td>
				Name
			</td>
			<td>
				{{$applicant->a_name}}
			</td>
		</tr>
		<tr>
			<td>
				Mobile No
			</td>
			<td>
				{{$applicant->a_mobile}}
			</td>
		</tr>
		<tr>
			<td>
				Email
			</td>
			<td>
				{{$applicant->a_email}}
			</td>
		</tr>
		<tr>
			<td>
				Present Address
			</td>
			<td>
				{{$applicant->a_present_address}}
			</td>
		</tr>
		<tr>
			<td>
				 Passing Year
			</td>
			<td>
				{{$applicant->a_passing_year}}
			</td>
		</tr>
    </table>
       @if(session('messageStatus')=='Matched Account Not Paid Successfully')
    	<div class="alert alert-danger alert-dismissable fade in">
		 	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times</a>
	    	{{session('messageStatus')}}
    	</div>
    	@else
    	<div class="alert alert-success alert-dismissable fade in">
		 	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times</a>
	    	{{session('messageStatus')}}
    	</div>	
	    @endif	
	 @endif   
</center>

@endsection