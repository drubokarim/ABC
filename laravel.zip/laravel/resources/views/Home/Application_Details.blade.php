@extends('Layout.layout')

@section('title')
Verification Page
@endsection

@section('component')
<center>
	<h2>
		Applicant Details
	</h2>
	<table class="table">
		<tr>
			<td>
				Name
			</td>
			<td>
				{{$applicant->a_name}}
			</td>
		</tr>
		<tr>
			<td>
				Mobile No
			</td>
			<td>
				{{$applicant->a_mobile}}
			</td>
		</tr>
		<tr>
			<td>
				Email
			</td>
			<td>
				{{$applicant->a_email}}
			</td>
		</tr>
		<tr>
			<td>
				Present Address
			</td>
			<td>
				{{$applicant->a_present_address}}
			</td>
		</tr>
		<tr>
			<td>
				 Passing Year
			</td>
			<td>
				{{$applicant->a_passing_year}}
			</td>
		</tr>	
		<tr>	
			<td>
				 Payment Status
			</td>
			<td>
				@if($applicant->a_ssl_payment_status=='Paid' && $applicant->a_payment_status=='Paid')
					Piad
				@else
					Unpaid
				@endif	
			</td>
		</tr>
		<tr>	
			<td>
				 Ticket Delivered
			</td>
			<td>
				 {{$applicant->delevery_status}}
			</td>
		</tr>
    </table>
    @if($applicant->delevery_status=='No')
    <form method="post">
    	{{csrf_field()}}
    	<input type="hidden" name="id" value="{{$applicant->a_id}}">
	    <input type="submit" name="" class="btn btn-primary btn-lg" value="Delivered">
	    <br>
	    <br>
	    
	     <input type="checkBox" name="check" id="checkbox">Tcket Delivered
	    @else
	     <div class="alert alert-success alert-dismissable fade in">
		 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times</a>
	    Ticket already delivered.
	    </div>
    </form>
    @endif   
    



			
	
		
</center>
@endsection