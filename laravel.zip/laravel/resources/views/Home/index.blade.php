@extends('Layout.layout')

@section('title')
Reporting Panel (Dashboard)
@endsection

@section('component')
<center>
	<h1>
		Dashboard and Statistics
	</h1>
	<table class="table" style="padding: 10px">
			<tr>
				<td >
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #00b3b3">{{session('reg')}}</h2>
						<p style=" color:  #d1d1e0;"> 
						Total Registrations
					     </p>
					</div>
				</td>
				<td>
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #ff751a">{{session('totalParticipant')}}</h2> 
						<p style="color:  #d1d1e0;">
						Total Participant
						</p>
					</div>
				</td>
				<td>
       
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #d1d1e0"> {{session('total')}}</h2>
						<p style="color:  #d1d1e0;"> 
						Total Paid
						</p>
					</div>
				</td>
				<td>
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #d1d1e0">{{session('guest')}}</h2>
						<p style="color:  #d1d1e0;"> 
						Total Guest
						</p>
					</div>
				</td>
				<td>
					<div class="jumbotron" style="text-align: center;">
						
						<h2 style="color:  #d1d1e0">{{session('ticket')}}</h2>
						<p style="color:  #d1d1e0;"> 
						Total Ticket Delivered
						</p>
					</div>
				</td>
			</tr>
		</table>
		<img src="{{asset('/photos/abc.PNG')}}" style="width: 100%">
	
</center>
@endsection