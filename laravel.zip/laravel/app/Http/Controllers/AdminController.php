<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AlumnuModelOL;
use App\CountryModelOL;
use Illuminate\Support\Facades\DB;
use Excel;
class AdminController extends Controller
{
    //
   //public static $flag=0;
   public function index()//dashboard
    {
        $registration_no=DB::table('alumnus')->count();
        $paid_no=DB::table('alumnus')
            ->where('a_ssl_payment_status','Paid')
            ->count();
        date_default_timezone_set('Asia/Dhaka');
        $update=date('Y-m-d H:i:s');
        $guestNo=DB::table('alumnus')
            ->where('a_guest_no','<>',NULL)->sum('a_guest_no'); 
        $guest=DB::table('alumnus')
            ->where('a_guest','=','yes')->count(); 
        $ticket=DB::table('alumnus')
                ->where('delevery_status','=','yes')->count(); 

        $totalParticipant=$registration_no+$guestNo-$guest;     
        session(['reg'=>$registration_no]);      
        session(['guest'=>$guestNo]);      
        session(['total'=>$paid_no]);
        session(['totalParticipant'=>$totalParticipant]);      
        session(['ticket'=>$ticket]);      
    	return view('Home.index');
               /*->with('reg',$registration_no)
               ->with('today',$today_paidNo)
               ->with('total',$paid_no);*/
    }
    public function show(Request $request)//show all the applicants
    {
        //AdminController::$flag=0;
        $applicants=DB::table('alumnus')
                    ->join('countries','alumnus.a_country','=','countries.id')
                    ->select('a_name','a_reg_no','a_mobile','a_ssl_payment_status','a_payment_status','country_name','a_guest','a_id')
                    ->paginate(5);
        $applicantsNo=DB::table('alumnus')
                    ->join('countries','alumnus.a_country','=','countries.id')
                    ->count();
        $request->session()->put('applicants',$applicants);
        $request->session()->put('flag',0);
        return view('Home.all_application_page')
                ->with('applicants',$applicants)
                ->with('applicantsNo',$applicantsNo);

    }
    public function showSearch(Request $request)//search and export to excel
    {
        if($request->submit=='Search')//search
        {
            
            $applicants=DB::table('alumnus')
                    ->join('countries','alumnus.a_country','=','countries.id')
                    ->where('a_name',$request->byName)
                    ->orWhere('a_reg_no',$request->uniqueCode)
                    ->orWhere('a_mobile',$request->searchByMobileNo)
                    ->orWhere('a_ssl_payment_status',$request->paidStatus)
                    ->select('a_name','a_reg_no','a_mobile','a_ssl_payment_status','a_payment_status','country_name','a_guest','a_id')
                    ->paginate(5);
            $applicantsNo=DB::table('alumnus')
                    ->join('countries','alumnus.a_country','=','countries.id')
                    ->where('a_name',$request->byName)
                    ->orWhere('a_reg_no',$request->uniqueCode)
                    ->orWhere('a_mobile',$request->searchByMobileNo)
                    ->orWhere('a_ssl_payment_status',$request->paidStatus)
                    ->count();
            $request->session()->put('applicants',$applicants);
            //$request->session()->put('CONDITION',$request);
            $request->session()->put('flag',1);
            $request->session()->put('byName',$request->byName);
            $request->session()->put('uniqueCode',$request->uniqueCode);
            $request->session()->put('searchByMobileNo',$request->searchByMobileNo);
            $request->session()->put('paidStatus',$request->paidStatus);

            return view('Home.all_application_page')
                    ->with('applicants',$applicants)
                    ->with('applicantsNo',$applicantsNo);


        }
        else//exporting to excel sheet
        {
            if(session('flag')==0)
            {
                $data=AlumnuModelOL::join('countries','alumnus.a_country','=','countries.id')
                ->select('a_name','a_reg_no','a_mobile','a_ssl_payment_status','a_payment_status','country_name','a_guest','a_id')
                ->get()
                ->toArray();

                return Excel::create('applicants', function($excel) use ($data) {
                $excel->sheet('mySheet', function($sheet) use ($data)
                {
                    $sheet->fromArray($data);
                });
                })->download('xls');

            }
            else{
                $data=AlumnuModelOL::join('countries','alumnus.a_country','=','countries.id')
                ->where('a_name',session('byName'))
                ->orWhere('a_reg_no',session('uniqueCode'))
                ->orWhere('a_mobile',session('searchByMobileNo'))
                ->orWhere('a_ssl_payment_status',session('paidStatus'))
                ->select('a_name','a_reg_no','a_mobile','a_ssl_payment_status','a_payment_status','country_name','a_guest','a_id')
                ->get()->toArray();

                return Excel::create('applicants', function($excel) use ($data) {
                $excel->sheet('mySheet', function($sheet) use ($data)
                {
                    $sheet->fromArray($data);
                });
                })->download('xls');

            }
        }
    }

    public function show_specific($id)//show specific applicant
    {
        $applicant=AlumnuModelOL::find($id);
    	return view('Home.Application_Details')
        ->with('applicant',$applicant);

    }
    public function show_specific_verify(Request $request)//check if ticket is deliverd or not
    {
        $id=$request->id;
        if($request->check==true)
        {
            $applicant=AlumnuModelOL::find($id);
            $applicant->delevery_status='Yes';
            $applicant->save();
        }
        return redirect()->route('home.show_specific',[$id]);
        //return view('Home.verify_registration');

    }
    public function show_verify($id)//verify an applicant(check payment status)
    {
        //$applicant=AlumnuModelOL::find($request->a_reg_no);
        return view('Home.verify_registration');
               // ->with('applicant',$applicant);

    }
    public function show_verify_update(Request $request)//check payment status
    {
        //$id=$request->id;
        $applicant=DB::table('alumnus')
                   ->where('a_reg_no',$request->regNo)->first();
        $request->session()->flash('messageStatus','Matched Account Not Paid Successfully');
        
        if($applicant->a_ssl_payment_status=='Paid'&&$applicant->a_payment_status=='Paid')
        {
            $request->session()->flash('messageStatus','Matched Account  Paid Successfully');

        }
    	return view('Home.verify_registration')
        ->with('applicant',$applicant);

    }

}
